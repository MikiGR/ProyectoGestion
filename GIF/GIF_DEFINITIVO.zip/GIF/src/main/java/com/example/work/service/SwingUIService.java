package com.example.work.service;

import com.example.work.front.VentanaPrincipal;
import org.springframework.stereotype.Service;

import javax.swing.*;

@Service
public class SwingUIService {

    private final UsuarioService usuarioService;
    private final MuestraService muestraService;
    private final SolucionService solucionService;

    public SwingUIService(UsuarioService usuarioService, MuestraService muestraService, SolucionService solucionService) {
        this.usuarioService = usuarioService;
        this.muestraService = muestraService;
        this.solucionService = solucionService;
    }

    public void startSwingUI() {
        VentanaPrincipal ventanaPrincipal = new VentanaPrincipal(usuarioService, muestraService, solucionService);

        ventanaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        ventanaPrincipal.setVisible(true);
    }
}